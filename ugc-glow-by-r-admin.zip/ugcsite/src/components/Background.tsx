import { motion } from "framer-motion";
import { Heart, Sparkle, Sparkles, Flower2, Star } from "lucide-react";

/* Floating decorative elements drifting around the page */
const floaters = [
  { Icon: Flower2, size: 26, top: "12%", left: "6%", delay: 0, dur: 7 },
  { Icon: Sparkle, size: 18, top: "22%", right: "9%", delay: 1.2, dur: 6 },
  { Icon: Heart, size: 20, top: "48%", left: "4%", delay: 0.6, dur: 8 },
  { Icon: Sparkles, size: 22, top: "64%", right: "6%", delay: 2, dur: 7.5 },
  { Icon: Star, size: 16, top: "82%", left: "10%", delay: 1.5, dur: 6.5 },
  { Icon: Sparkle, size: 14, top: "36%", right: "16%", delay: 0.3, dur: 9 },
  { Icon: Flower2, size: 20, top: "78%", right: "14%", delay: 2.4, dur: 8.5 },
];

export default function Background() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" aria-hidden>
      {/* base wash */}
      <div className="absolute inset-0 bg-gradient-to-b from-blush-50 via-[#fff2f7] to-blush-100" />

      {/* drifting gradient blobs */}
      <motion.div
        className="absolute -top-32 -left-32 w-[34rem] h-[34rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, #ffd9e8 0%, transparent 65%)" }}
        animate={{ x: [0, 60, 0], y: [0, 40, 0] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute top-1/3 -right-40 w-[38rem] h-[38rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, #ffcfe3 0%, transparent 65%)" }}
        animate={{ x: [0, -50, 0], y: [0, 60, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute -bottom-40 left-1/4 w-[30rem] h-[30rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, #ffe6f0 0%, transparent 65%)" }}
        animate={{ x: [0, 40, 0], y: [0, -50, 0] }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* drifting dainty icons */}
      {floaters.map(({ Icon, size, delay, dur, ...pos }, i) => (
        <motion.div
          key={i}
          className="absolute text-blush-400/50"
          style={pos as React.CSSProperties}
          animate={{ y: [0, -16, 0], rotate: [0, 8, -6, 0] }}
          transition={{ duration: dur, repeat: Infinity, ease: "easeInOut", delay }}
        >
          <Icon size={size} strokeWidth={1.5} />
        </motion.div>
      ))}

      {/* soft vignette at edges */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(248,168,198,0.14)_100%)]" />
    </div>
  );
}
