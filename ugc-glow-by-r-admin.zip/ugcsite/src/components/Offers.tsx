import { useState } from "react";
import { motion } from "framer-motion";
import { BadgePercent, Check, Copy, Timer, ArrowUpRight } from "lucide-react";
import PageShell from "./PageShell";
import InstagramIcon from "./InstagramIcon";
import { useSiteData } from "../siteData";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 140, damping: 18 } },
};

export default function Offers({ back }: { back: () => void }) {
  const { data } = useSiteData();
  const { offers, instagramUrl: INSTAGRAM_URL, instagramHandle: INSTAGRAM_HANDLE } = data;
  const [copied, setCopied] = useState<string | null>(null);

  const copy = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      /* clipboard blocked — still show feedback */
    }
    setCopied(code);
    setTimeout(() => setCopied(null), 1600);
  };

  return (
    <PageShell
      eyebrow="Current Deals"
      title="Fresh"
      italicWord="Offers"
      subtitle="Brand offers & current deals — grab them while they last"
      onBack={back}
    >
      <motion.div variants={container} initial="hidden" animate="show" className="flex flex-col gap-4">
        {offers.map((o) => (
          <motion.article
            key={o.brand + o.title}
            variants={item}
            whileHover={{ y: -3 }}
            className="group relative rounded-3xl bg-white/85 backdrop-blur-md border border-blush-200/90 p-5 shadow-petal hover:shadow-petallift transition-shadow duration-500 overflow-hidden"
          >
            <span className="shine-sweep" />
            <div className="flex items-center justify-between gap-3">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-blush-400 to-blush-600 px-3 py-1 text-[10px] tracking-[0.18em] uppercase text-white font-medium shadow-petal">
                <BadgePercent size={11} /> {o.tag}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] tracking-[0.14em] uppercase text-wine-800/50">
                <Timer size={11} /> {o.valid}
              </span>
            </div>

            <h3 className="mt-3.5 font-serif text-2xl leading-snug text-wine-900">{o.brand}</h3>
            <p className="text-sm font-medium text-blush-600">{o.title}</p>
            <p className="mt-1 text-[12.5px] leading-relaxed text-wine-800/60">{o.detail}</p>

            {o.code ? (
              <button
                onClick={() => copy(o.code!)}
                className="mt-4 w-full flex items-center justify-between rounded-full border border-dashed border-blush-400/70 bg-blush-50/80 px-4 py-2.5 transition-colors hover:bg-blush-100"
              >
                <span className="text-sm font-semibold tracking-[0.28em] text-wine-900">{o.code}</span>
                <span className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.2em] uppercase text-blush-600 font-medium">
                  {copied === o.code ? (
                    <>
                      <Check size={12} className="text-emerald-500" />
                      <span className="text-emerald-600">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy size={12} /> Tap to copy
                    </>
                  )}
                </span>
              </button>
            ) : (
              <div className="mt-4 rounded-full border border-dashed border-blush-300 bg-blush-50/60 px-4 py-2.5 text-center text-[11px] tracking-[0.14em] uppercase text-blush-600">
                Mention {INSTAGRAM_HANDLE} at checkout
              </div>
            )}
          </motion.article>
        ))}

        {/* collab CTA */}
        <motion.a
          variants={item}
          href={INSTAGRAM_URL}
          target="_blank"
          rel="noreferrer"
          whileHover={{ y: -3 }}
          className="group relative mt-2 flex items-center justify-between rounded-3xl px-5 py-4 text-white shadow-petal-lg overflow-hidden"
          style={{ background: "linear-gradient(120deg, #ec85b0 0%, #d85f92 55%, #b34473 100%)" }}
        >
          <span className="shine-sweep" />
          <div className="flex items-center gap-3">
            <span className="grid place-items-center w-10 h-10 rounded-2xl bg-white/20">
              <InstagramIcon size={18} />
            </span>
            <div>
              <p className="font-serif text-lg leading-tight">Want your brand here?</p>
              <p className="text-[11px] tracking-[0.18em] uppercase text-white/75">DM “OFFER” on Instagram</p>
            </div>
          </div>
          <ArrowUpRight size={18} className="transition-transform duration-500 group-hover:rotate-45" />
        </motion.a>
      </motion.div>
    </PageShell>
  );
}
