import { motion } from "framer-motion";
import InstagramIcon from "./InstagramIcon";
import { useSiteData } from "../siteData";

type Props = {
  label?: string;
  showHandle?: boolean;
};

export default function InstagramButton({ label = "Follow on Instagram", showHandle = true }: Props) {
  const { data } = useSiteData();
  const { instagramUrl: INSTAGRAM_URL, instagramHandle: INSTAGRAM_HANDLE } = data;
  return (
    <motion.a
      href={INSTAGRAM_URL}
      target="_blank"
      rel="noreferrer"
      whileHover={{ scale: 1.04, y: -2 }}
      whileTap={{ scale: 0.96 }}
      className="group relative inline-flex items-center gap-3 rounded-full px-6 py-3.5 text-white shadow-petal-lg overflow-hidden"
      style={{ background: "linear-gradient(120deg, #ec85b0 0%, #d85f92 55%, #b34473 100%)" }}
    >
      <span className="shine-sweep" />
      <span className="grid place-items-center w-7 h-7 rounded-full bg-white/20 backdrop-blur-sm">
        <InstagramIcon size={16} strokeWidth={2} />
      </span>
      <span className="text-sm font-medium tracking-wide">{label}</span>
      {showHandle && <span className="text-[11px] tracking-[0.18em] uppercase text-white/80">{INSTAGRAM_HANDLE}</span>}
    </motion.a>
  );
}
