import { motion } from "framer-motion";
import { ArrowUpRight, Heart, ShoppingBag } from "lucide-react";
import PageShell from "./PageShell";
import { useSiteData } from "../siteData";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 140, damping: 18 } },
};

export default function PRLinks({ back }: { back: () => void }) {
  const { data } = useSiteData();
  const { products } = data;
  return (
    <PageShell
      eyebrow="Gifted & Loved"
      title="PR"
      italicWord="Links"
      subtitle="Products & PR collaborations — shop my current favourites"
      onBack={back}
    >
      <motion.div variants={container} initial="hidden" animate="show" className="flex flex-col gap-4">
        {products.map((p) => (
          <motion.a
            key={p.name}
            variants={item}
            href={p.link}
            target="_blank"
            rel="noreferrer"
            whileHover={{ y: -3 }}
            whileTap={{ scale: 0.985 }}
            className="group relative flex items-center gap-4 rounded-3xl bg-white/85 backdrop-blur-md border border-blush-200/90 p-3.5 pr-5 shadow-petal hover:shadow-petallift transition-shadow duration-500 overflow-hidden"
          >
            <span className="shine-sweep" />
            <div className="relative w-24 h-24 shrink-0 rounded-2xl overflow-hidden ring-1 ring-blush-200 shadow-sm">
              <img
                src={p.image}
                alt={p.name}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
              />
              <span className="absolute inset-0 bg-gradient-to-t from-blush-900/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] tracking-[0.28em] uppercase text-blush-600 font-medium">{p.brand}</p>
              <h3 className="font-serif text-lg leading-snug text-wine-900 truncate">{p.name}</h3>
              <p className="text-[11.5px] text-wine-800/55 italic">{p.note}</p>
              <div className="mt-2 flex items-center gap-2">
                <span className="rounded-full bg-blush-100 px-2.5 py-0.5 text-[11px] font-semibold text-rose-700">{p.price}</span>
                <span className="inline-flex items-center gap-1 text-[10px] tracking-[0.18em] uppercase text-blush-600 font-medium">
                  <ShoppingBag size={11} /> Shop
                </span>
              </div>
            </div>
            <div className="grid place-items-center w-9 h-9 shrink-0 rounded-full border border-blush-300/80 text-blush-600 transition-all duration-500 group-hover:bg-gradient-to-br group-hover:from-blush-400 group-hover:to-blush-600 group-hover:text-white group-hover:border-transparent group-hover:rotate-45">
              <ArrowUpRight size={15} />
            </div>
          </motion.a>
        ))}

        <motion.p
          variants={item}
          className="mt-2 flex items-center justify-center gap-2 rounded-full bg-white/60 backdrop-blur border border-blush-200/70 px-4 py-3 text-[11px] tracking-[0.14em] uppercase text-wine-800/55 text-center"
        >
          <Heart size={12} className="text-blush-500 fill-blush-200 shrink-0" />
          PR & affiliate links — I only share what I truly love
        </motion.p>
      </motion.div>
    </PageShell>
  );
}
