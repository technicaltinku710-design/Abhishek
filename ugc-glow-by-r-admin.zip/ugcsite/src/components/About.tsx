import { motion } from "framer-motion";
import { Mail, MapPin, Sparkles, Star } from "lucide-react";
import PageShell from "./PageShell";
import { useSiteData } from "../siteData";
import InstagramIcon from "./InstagramIcon";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 140, damping: 18 } },
};

export default function About({ back }: { back: () => void }) {
  const { data } = useSiteData();
  const { about, avatar: AVATAR, collabEmail: COLLAB_EMAIL, instagramUrl: INSTAGRAM_URL, instagramHandle: INSTAGRAM_HANDLE } = data;
  return (
    <PageShell
      eyebrow="Meet R"
      title="About"
      italicWord="Me"
      subtitle="About the creator & how to reach her"
      onBack={back}
    >
      <motion.div variants={container} initial="hidden" animate="show" className="flex flex-col gap-4">
        {/* bio card */}
        <motion.section
          variants={item}
          className="relative rounded-3xl bg-white/85 backdrop-blur-md border border-blush-200/90 p-6 shadow-petal overflow-hidden"
        >
          <div className="absolute -top-10 -right-10 w-36 h-36 rounded-full bg-blush-200/50 blur-2xl" />
          <div className="flex items-center gap-4">
            <img src={AVATAR} alt="R" className="w-16 h-16 rounded-2xl object-cover ring-2 ring-blush-200 shadow-petal" />
            <div>
              <h3 className="font-serif text-2xl text-wine-900">{about.heading}</h3>
              <p className="font-script text-xl text-blush-600 leading-none">{about.script}</p>
            </div>
          </div>
          {about.paragraphs.map((p, i) => (
            <p key={i} className="mt-4 text-[13px] leading-relaxed text-wine-800/70">
              {p}
            </p>
          ))}
          <p className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-blush-100/80 px-3 py-1.5 text-[10.5px] tracking-[0.16em] uppercase text-rose-700">
            <MapPin size={12} /> {about.location}
          </p>
        </motion.section>

        {/* stats */}
        <motion.div variants={item} className="grid grid-cols-3 gap-3">
          {about.stats.map((s) => (
            <div key={s.label} className="rounded-3xl bg-white/85 backdrop-blur-md border border-blush-200/90 py-4 px-2 text-center shadow-petal">
              <p className="font-serif text-[1.55rem] leading-none bg-gradient-to-r from-blush-600 to-rose-700 bg-clip-text text-transparent font-medium">
                {s.value}
              </p>
              <p className="mt-1.5 text-[9.5px] tracking-[0.18em] uppercase text-wine-800/55">{s.label}</p>
            </div>
          ))}
        </motion.div>

        {/* services */}
        <motion.section variants={item} className="rounded-3xl bg-white/85 backdrop-blur-md border border-blush-200/90 p-5 shadow-petal">
          <p className="inline-flex items-center gap-2 text-[10px] tracking-[0.32em] uppercase text-blush-600 font-medium">
            <Sparkles size={12} /> What I create
          </p>
          <div className="mt-3.5 flex flex-wrap gap-2">
            {about.services.map((s) => (
              <span key={s} className="rounded-full border border-blush-300/80 bg-blush-50/80 px-3.5 py-1.5 text-[11px] tracking-wide text-wine-800">
                {s}
              </span>
            ))}
          </div>
        </motion.section>

        {/* contact */}
        <motion.section variants={item} className="rounded-3xl bg-white/85 backdrop-blur-md border border-blush-200/90 p-5 shadow-petal">
          <p className="inline-flex items-center gap-2 text-[10px] tracking-[0.32em] uppercase text-blush-600 font-medium">
            <Star size={12} /> Work with me
          </p>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <motion.a
              href={`mailto:${COLLAB_EMAIL}`}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.96 }}
              className="flex flex-col items-center gap-1.5 rounded-2xl border border-blush-300/80 bg-blush-50/80 px-3 py-4 text-center transition-colors hover:bg-blush-100"
            >
              <Mail size={18} className="text-blush-600" />
              <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-wine-900">Email</span>
              <span className="text-[10px] text-wine-800/55 break-all leading-tight">{COLLAB_EMAIL}</span>
            </motion.a>
            <motion.a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noreferrer"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.96 }}
              className="flex flex-col items-center gap-1.5 rounded-2xl px-3 py-4 text-center text-white shadow-petal-lg"
              style={{ background: "linear-gradient(120deg, #ec85b0 0%, #d85f92 55%, #b34473 100%)" }}
            >
              <InstagramIcon size={18} />
              <span className="text-[11px] font-semibold tracking-[0.14em] uppercase">DM on Insta</span>
              <span className="text-[10px] text-white/75">{INSTAGRAM_HANDLE}</span>
            </motion.a>
          </div>
          <p className="mt-4 text-center text-[11px] tracking-[0.14em] uppercase text-wine-800/50">
            PR packages & rates on request
          </p>
        </motion.section>
      </motion.div>
    </PageShell>
  );
}
