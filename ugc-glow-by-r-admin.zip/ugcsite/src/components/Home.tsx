import { motion } from "framer-motion";
import { ArrowUpRight, Gift, Heart, Instagram, Sparkles } from "lucide-react";
import type { View } from "../App";
import { useSiteData } from "../siteData";
import InstagramButton from "./InstagramButton";

const slots: { key: Exclude<View, "home">; title: string; desc: string; Icon: typeof Gift }[] = [
  { key: "offers", title: "Offers", desc: "Brand offers & current deals", Icon: Sparkles },
  { key: "pr", title: "PR Links", desc: "Products & PR collaborations", Icon: Gift },
  { key: "about", title: "About", desc: "About the creator & contact", Icon: Heart },
];

const item = {
  hidden: { opacity: 0, y: 18 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 140, damping: 18 } },
};

export default function Home({ go }: { go: (v: View) => void }) {
  const { data } = useSiteData();
  const { avatar: AVATAR, brand: BRAND } = data;
  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, y: -14 }}
      transition={{ duration: 0.3 }}
      className="relative z-10 min-h-dvh flex justify-center px-5 py-12 sm:py-16"
    >
      <div className="w-full max-w-md flex flex-col items-center text-center">
        <motion.div variants={item} initial="hidden" animate="show" className="relative">
          <div className="absolute -inset-3 rounded-full bg-blush-300/30 blur-xl" />
          <img
            src={AVATAR}
            alt="UGC Glow By R"
            className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover ring-4 ring-white shadow-petal-lg"
          />
        </motion.div>

        <motion.div variants={item} initial="hidden" animate="show" className="mt-6">
          <p className="text-[10px] tracking-[0.42em] uppercase text-blush-600 font-medium">{BRAND.nameTop}</p>
          <h1 className="mt-1 font-serif text-5xl sm:text-6xl leading-none text-wine-900">
            <em className="italic font-medium bg-gradient-to-r from-blush-600 to-rose-700 bg-clip-text text-transparent">{BRAND.nameMid}</em>
          </h1>
          <p className="font-script text-3xl text-blush-600 mt-1">{BRAND.nameBottom}</p>
          <p className="mt-4 text-[12px] tracking-[0.16em] uppercase text-wine-800/65">{BRAND.tagline}</p>
        </motion.div>

        <motion.div variants={item} initial="hidden" animate="show" className="mt-8 w-full flex flex-col gap-3.5">
          {slots.map(({ key, title, desc, Icon }) => (
            <motion.button
              key={key}
              whileHover={{ y: -3 }}
              whileTap={{ scale: 0.985 }}
              onClick={() => go(key)}
              className="group relative w-full text-left rounded-2xl bg-white/90 backdrop-blur border border-blush-200 p-4 sm:p-5 shadow-petal hover:shadow-petallift transition-all duration-300 overflow-hidden"
            >
              <span className="shine-sweep" />
              <div className="flex items-center gap-4">
                <span className="grid place-items-center w-12 h-12 shrink-0 rounded-xl bg-blush-100 text-blush-600 border border-blush-200 transition-transform duration-300 group-hover:scale-105">
                  <Icon size={21} strokeWidth={1.8} />
                </span>
                <span className="flex-1 min-w-0">
                  <span className="block font-serif text-[1.45rem] leading-tight text-wine-900">{title}</span>
                  <span className="block mt-0.5 text-[12px] text-wine-800/60">{desc}</span>
                </span>
                <span className="grid place-items-center w-9 h-9 shrink-0 rounded-full border border-blush-200 text-blush-600 transition-all duration-300 group-hover:bg-blush-500 group-hover:text-white group-hover:border-blush-500">
                  <ArrowUpRight size={15} />
                </span>
              </div>
            </motion.button>
          ))}
        </motion.div>

        <motion.div variants={item} initial="hidden" animate="show" className="mt-8">
          <InstagramButton label="Follow on Instagram" showHandle={false} />
        </motion.div>

        <motion.p variants={item} initial="hidden" animate="show" className="mt-6 flex items-center gap-1.5 text-[10px] tracking-[0.18em] uppercase text-wine-800/40">
          <Instagram size={11} /> {INSTAGRAM_HANDLE}
        </motion.p>
      </div>
            <button onClick={() => go("admin")} className="mt-5 text-[9px] tracking-[0.2em] uppercase text-wine-800/25 hover:text-blush-600">Creator login</button>
      </motion.main>
  );
}
