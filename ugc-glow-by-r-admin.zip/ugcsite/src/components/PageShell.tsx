import { motion } from "framer-motion";
import { ChevronLeft, Sparkles } from "lucide-react";
import type { ReactNode } from "react";
import InstagramButton from "./InstagramButton";

type Props = {
  eyebrow: string;
  title: string;
  italicWord?: string;
  subtitle: string;
  onBack: () => void;
  children: ReactNode;
};

export default function PageShell({ eyebrow, title, italicWord, subtitle, onBack, children }: Props) {
  return (
    <motion.main
      initial={{ opacity: 0, y: 28, scale: 0.985 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -20, scale: 0.99 }}
      transition={{ type: "spring", stiffness: 120, damping: 18 }}
      className="relative z-10 min-h-dvh flex justify-center px-4 py-8 sm:py-12"
    >
      <div className="w-full max-w-md">
        {/* top bar */}
        <div className="flex items-center justify-between">
          <motion.button
            onClick={onBack}
            whileHover={{ x: -3 }}
            whileTap={{ scale: 0.94 }}
            className="flex items-center gap-1.5 rounded-full bg-white/80 backdrop-blur px-4 py-2 text-xs font-medium tracking-wide text-wine-800 border border-blush-200 shadow-petal"
          >
            <ChevronLeft size={15} />
            Home
          </motion.button>
          <span className="font-script text-2xl text-blush-600">glow by R</span>
          <span className="w-[86px]" />
        </div>

        {/* header */}
        <header className="mt-10 text-center">
          <p className="inline-flex items-center gap-2 text-[11px] tracking-[0.32em] uppercase text-blush-600 font-medium">
            <Sparkles size={12} /> {eyebrow} <Sparkles size={12} />
          </p>
          <h1 className="mt-3 font-serif text-5xl sm:text-6xl text-wine-900 leading-[1.05]">
            {title}{" "}
            {italicWord && (
              <em className="italic font-medium bg-gradient-to-r from-blush-600 to-blush-400 bg-clip-text text-transparent">
                {italicWord}
              </em>
            )}
          </h1>
          <p className="mt-3 text-sm text-wine-800/70 tracking-wide">{subtitle}</p>
          <div className="divider-dots w-24 mx-auto mt-5" />
        </header>

        {/* content */}
        <div className="mt-8">{children}</div>

        {/* footer */}
        <footer className="mt-12 flex flex-col items-center gap-4 pb-6">
          <div className="divider-dots w-40" />
          <InstagramButton label="DM to collab" />
          <p className="text-[11px] tracking-[0.2em] uppercase text-wine-800/50">
            @ugcglowbyr · beauty · lifestyle
          </p>
        </footer>
      </div>
    </motion.main>
  );
}
