import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { DEFAULT_DATA, type SiteData } from "./data";

const URL = (import.meta.env.VITE_SUPABASE_URL || "").replace(/\/$/, "");
const KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || "";
export const supabaseConfigured = Boolean(URL && KEY);
const headers = { apikey: KEY, "Content-Type": "application/json" };

export async function loadSiteData(): Promise<SiteData> {
  if (!supabaseConfigured) return DEFAULT_DATA;
  const r = await fetch(`${URL}/rest/v1/site_content?id=eq.1&select=content`, { headers });
  if (!r.ok) throw new Error("Could not load website content");
  const rows = await r.json();
  return rows[0]?.content || DEFAULT_DATA;
}

export async function saveSiteData(content: SiteData, token: string) {
  if (!supabaseConfigured) throw new Error("Supabase is not configured yet.");
  const r = await fetch(`${URL}/rest/v1/site_content`, {
    method: "POST",
    headers: { ...headers, Authorization: `Bearer ${token}`, Prefer: "resolution=merge-duplicates,return=minimal" },
    body: JSON.stringify({ id: 1, content, updated_at: new Date().toISOString() }),
  });
  if (!r.ok) throw new Error(await r.text());
}

export async function login(email: string, password: string) {
  if (!supabaseConfigured) throw new Error("Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in Vercel first.");
  const r = await fetch(`${URL}/auth/v1/token?grant_type=password`, { method: "POST", headers, body: JSON.stringify({ email, password }) });
  const body = await r.json();
  if (!r.ok) throw new Error(body.error_description || body.msg || "Login failed");
  return body as { access_token: string; refresh_token: string };
}

const Ctx = createContext<{ data: SiteData; setData: (d: SiteData) => void; loading: boolean }>({ data: DEFAULT_DATA, setData: () => {}, loading: true });
export function SiteDataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState(DEFAULT_DATA);
  const [loading, setLoading] = useState(true);
  useEffect(() => { loadSiteData().then(setData).catch(() => {}).finally(() => setLoading(false)); }, []);
  return <Ctx.Provider value={{ data, setData, loading }}>{children}</Ctx.Provider>;
}
export const useSiteData = () => useContext(Ctx);
