export const DEFAULT_DATA = {
  instagramHandle: "@ugcglowbyr",
  instagramUrl: "https://instagram.com/ugcglowbyr",
  collabEmail: "hello.glowbyr@gmail.com",
  avatar: "/images/avatar.jpg",
  brand: {
    nameTop: "UGC", nameMid: "Glow", nameBottom: "by R",
    tagline: "UGC Creator • Beauty • Lifestyle",
    bio: "Soft-girl aesthetics, honest reviews & scroll-stopping content for beauty and lifestyle brands.",
  },
  offers: [
    { brand: "Rosé Beauty Box", title: "15% OFF gifting boxes", detail: "Curated self-care boxes — best sellers + limited drops.", code: "GLOW15", valid: "Valid till 30 Apr", tag: "Exclusive" },
    { brand: "Petal & Co.", title: "Buy 1 Get 1 on lip oils", detail: "All shades included. Add 2 to cart, discount auto-applies.", code: "RPETAL", valid: "While stocks last", tag: "Hot deal" },
    { brand: "Glowcart Beauty", title: "₹200 OFF above ₹999", detail: "Skincare & makeup, sitewide on premium brands.", code: "UGCBYR", valid: "Valid till 15 May", tag: "Site-wide" },
    { brand: "Velour Skin", title: "Free mini serum on every PR order", detail: "Mention my handle in notes to claim the gift.", valid: "Ongoing", tag: "PR perk" },
  ],
  products: [
    { name: "Rose Quartz Serum", brand: "Velour Skin", note: "Glass-skin glow in a bottle", price: "₹899", image: "/images/product-serum.jpg", link: "https://instagram.com/ugcglowbyr" },
    { name: "Petal Lip Oil — 03 Rose", brand: "Petal & Co.", note: "My everyday glossy tint", price: "₹449", image: "/images/product-lipoil.jpg", link: "https://instagram.com/ugcglowbyr" },
    { name: "Cloud Cream SPF 30", brand: "Glowcart Beauty", note: "No white cast, dewy finish", price: "₹699", image: "/images/product-cream.jpg", link: "https://instagram.com/ugcglowbyr" },
    { name: "Silk Blush Compact", brand: "Rosé Beauty Box", note: "The perfect soft-pink flush", price: "₹549", image: "/images/product-blush.jpg", link: "https://instagram.com/ugcglowbyr" },
  ],
  about: {
    heading: "Hi, I'm R", script: "the girl behind the glow",
    paragraphs: [
      "I'm a UGC creator crafting soft, dreamy, scroll-stopping content for beauty & lifestyle brands. From unboxings and GRWMs to aesthetic product photography — I turn products into little love stories.",
      "Every collab is shot with natural light, honest opinions and a whole lot of pink. If your brand believes in authentic storytelling, we'll glow really well together.",
    ],
    location: "Mumbai, India · working worldwide",
    stats: [{ value: "60+", label: "Brand collabs" }, { value: "12K+", label: "IG community" }, { value: "4.9", label: "Avg. brand rating" }],
    services: ["Product UGC", "Unboxing reels", "GRWM / tutorials", "Voiceover ads", "UGC photography"],
  },
};

export type SiteData = typeof DEFAULT_DATA;
export type Offer = SiteData["offers"][number];
export type Product = SiteData["products"][number];
