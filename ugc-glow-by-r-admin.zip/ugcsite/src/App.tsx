import { useEffect, useState } from "react";
import { AnimatePresence } from "framer-motion";
import Background from "./components/Background";
import Home from "./components/Home";
import Offers from "./components/Offers";
import PRLinks from "./components/PRLinks";
import About from "./components/About";
import Admin from "./components/Admin";
import { SiteDataProvider } from "./siteData";

export type View = "home" | "offers" | "pr" | "about" | "admin";

const viewFromHash = (): View => {
  const h = window.location.hash.replace("#", "");
  return h === "offers" || h === "pr" || h === "about" || h === "admin" ? h : "home";
};

export default function App() {
  const [view, setView] = useState<View>(viewFromHash);

  useEffect(() => {
    const onHash = () => setView(viewFromHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [view]);

  const go = (v: View) => {
    window.location.hash = v === "home" ? "" : v;
    setView(v);
  };

  const back = () => go("home");

  return (
    <SiteDataProvider>
    <div className="grain relative min-h-dvh font-sans">
      <Background />
      <AnimatePresence mode="wait">
        {view === "home" && <Home key="home" go={go} />}
        {view === "offers" && <Offers key="offers" back={back} />}
        {view === "pr" && <PRLinks key="pr" back={back} />}
        {view === "about" && <About key="about" back={back} />}
        {view === "admin" && <Admin key="admin" back={back} />}
      </AnimatePresence>
    </div>
    </SiteDataProvider>
  );
}
