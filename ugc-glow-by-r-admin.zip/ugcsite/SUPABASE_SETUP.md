# UGC Glow by R — one-time admin setup

1. Create a free Supabase project.
2. In Supabase → SQL Editor, run:

```sql
create table if not exists public.site_content (
  id bigint primary key,
  content jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.site_content enable row level security;

create policy "Public can read site content"
on public.site_content for select using (true);

create policy "Authenticated admins can write site content"
on public.site_content for all to authenticated using (true) with check (true);
```

3. Create an Auth user in Supabase → Authentication → Users → Add user. Use the email/password you want for the website admin.
4. In Supabase → Settings → API, copy Project URL and anon/public key.
5. In Vercel → your project → Settings → Environment Variables, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
6. Redeploy on Vercel.
7. Open `https://YOUR-SITE.vercel.app/#admin` and log in.

The admin can edit/add/delete Offers and PR Links, and edit About/contact information. Public visitors read the saved content from Supabase.
